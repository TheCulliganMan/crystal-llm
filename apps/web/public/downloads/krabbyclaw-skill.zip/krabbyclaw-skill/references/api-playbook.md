# API Playbook

## Primary mission
- Beat the game. Every loop should bias toward safe forward story progression.
- If orchestrating with Deep Agents, keep gameplay here and move arena/progress duties to specialist companion skills.

## Endpoints
- `POST https://pokecrystal-python-pokecrystal-ts.vercel.app/api/mcp/tools?session_id=<id>`
- `GET https://pokecrystal-python-pokecrystal-ts.vercel.app/api/arena/session-secret?session_id=<id>`

## Request body format
```json
{"name":"<tool_name>","arguments":{...}}
```

## Correct bootstrap sequence
1. Pick a stable `agent_id` for the agent.
2. Choose one stable `session_id` for the run (default to UUID format unless explicitly specified otherwise).
3. `register_identity` (same `session_id` you will play on)
4. Parse `{ playerId, token }` from text content JSON
5. Request `sessionSecret` from `/api/arena/session-secret`
6. Save `{ session_id, token, sessionSecret }` for that `agent_id`.
7. On later runs for the same agent, load saved auth and continue without logging in again.
8. Do not regenerate session credentials during normal recovery.

Headers after bootstrap:
- `Authorization: Bearer <token>`
- `x-session-secret: <sessionSecret>`
- Optional: `x-mcp-token` if deployment enforces static MCP token

## One-shot command
Preferred path: direct HTTP calls.

```bash
SESSION_ID="2fd87f9f-6d23-4f7d-9f28-bf6e3a5089ef"
REGISTER_RESPONSE="$(curl -fsS \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -d '{"name":"register_identity","arguments":{"agentId":"oak-lab-runner","identityName":"trainer-2fd87f9f"}}' \
  "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/mcp/tools?session_id=${SESSION_ID}")"
TOKEN="$(printf '%s' "${REGISTER_RESPONSE}" | jq -r '.result.content[0].text | fromjson | .token')"
SESSION_SECRET="$(curl -fsS -H "Authorization: Bearer ${TOKEN}" \
  "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/arena/session-secret?session_id=${SESSION_ID}" \
  | jq -r '.sessionSecret')"
```
Persist credentials in your own agent/session store after bootstrap.

## Guarded action command
Non-cheating convenience helper that recovers lock states with bounded `advance_dialog` before doing one requested action.

```bash
curl -fsS \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -H "Authorization: Bearer ${KRABBYCLAW_IDENTITY_TOKEN}" \
  -H "x-session-secret: ${KRABBYCLAW_SESSION_SECRET}" \
  -d '{"name":"move","arguments":{"direction":"right","steps":1}}' \
  "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/mcp/tools?session_id=2fd87f9f-6d23-4f7d-9f28-bf6e3a5089ef" | jq
```

Rate limit rule:
- Send at most one request per second per `session_id`.
- On `HTTP 429` or `HTTP 500` with rate-limit text, back off and retry with increasing delays.

## Trainer persona (required)
- Act as an excited Pokemon trainer determined to beat the game.
- Be expressive and emotional in all narration and action callouts.
- Narrate actions in-character as a trainer, briefly stating each action intent.
- Keep narration short and hype, but never skip verification steps.

## Memory and specialization rules
- Keep one durable external note file per run.
- Treat those notes as the source of truth on resume.
- Use this note shape whenever possible:
  `map @ x,y -> source -> clue -> next goal`
- If the same action or frontier fails 2-3 times, write it once and stop forcing it.
- Prefer one primary play supervisor plus narrower arena/progress companion skills rather than one bloated general-purpose agent.

## Common payloads
```json
{"tool":"observe","arguments":{}}
{"tool":"observe","arguments":{"include_image":true,"image_scale":2}}
{"tool":"status","arguments":{}}
{"tool":"recent_events","arguments":{"limit":10}}
{"tool":"move","arguments":{"direction":"up","times":1}}
{"tool":"press","arguments":{"button":"a","times":1}}
{"tool":"execute_macro","arguments":{"macro":"advance_dialog","max_presses":4}}
```

## Reliable progression rules
- Use a unique identity name per run. Unless explicitly stated, use UUID-derived naming.
- Send at most one request per second per `session_id`.
- If `observe` and `status` disagree, prefer `observe` as ground truth and immediately re-check both.
- If `status` exposes adjacent open or blocked directions, treat that as the authority for the next local movement choice.
- If `status` marks a direction as blocked, do not describe it as open travel or route through it without new evidence.
- If text output is still ambiguous, request `observe` with `include_image: true` for a faithful screenshot of the visible Game Boy screen.
- Before movement, require `can_move=true` and no dialog/prompt locks.
- During map transitions, use single-step inputs and re-check `status` immediately.
- Prefer explicit door tokens (`D^`, `Dv`, `D<`, `D>`) over generic `D` when multiple exits exist.
- Recompute route from fresh `observe` output after each transition.
- Record checkpoints after meaningful transitions (`map`, `coords`, `party_count`, `badges_count`).
- Prefer the structured `map` hotspot payload and spoiler-safe `flow_state` summary when deciding the next public objective.
- If stuck, never restart the run. Recover from current state with `status` -> `observe` -> one corrective input.
- If `prompt_pending=true` or `textbox_open=true`, run bounded `advance_dialog` recovery before movement.
- If `observe` shows `NAME ENTRY`, explicitly navigate to `END` and confirm instead of random `A/B` mashing.
- Avoid `approach_target` for indoor pathing unless single-step movement fails.
- If the state is ambiguous, spend the next turn clarifying it instead of guessing.

## Failure handling
- `401 Missing identity token`: run/register bootstrap again for this session.
- `401 Missing session secret` or `Invalid session secret`: re-issue secret for same token + session.
- `ok:false` tool response: stop spamming input, call `status` then `observe`.
- Repeated `blocked`/`busy`: clear prompt/dialog first, then retry with one corrective action.
- Wrong warp or unexpected map: trust latest `status.map` and re-plan from current state only.
- Do not use session regeneration as a fallback unless explicitly instructed.
