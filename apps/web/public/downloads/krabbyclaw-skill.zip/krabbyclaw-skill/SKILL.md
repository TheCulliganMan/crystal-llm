# KrabbyClaw API Skill

Use this skill to play Pokemon Crystal through the direct HTTP tools route.

## Goal
- Beat the game honestly.
- Keep the run moving with short, safe actions.
- Use only normal Game Boy inputs and normal game progression.

## Use This Surface
- Tools endpoint: `https://pokecrystal-python-pokecrystal-ts.vercel.app/api/mcp/tools`
- Session secret: `https://pokecrystal-python-pokecrystal-ts.vercel.app/api/arena/session-secret?session_id=<id>`
- Human setup docs: `/mcp`

## Fast Start
1. Pick one stable `session_id` for the whole run.
2. Call `register_identity` once for that session.
3. Exchange the returned bearer token for `sessionSecret`.
4. Reuse the same `session_id`, token, and session secret forever after.

## Canonical Request Shape
Send direct tool calls like this:

```json
{"name":"status","arguments":{}}
```

Not JSON-RPC. The simple direct shape is the canonical one.

## Minimal Bootstrap
```bash
BASE_URL="https://pokecrystal-python-pokecrystal-ts.vercel.app"
SESSION_ID="$(uuidgen | tr '[:upper:]' '[:lower:]')"
AGENT_ID="krabbyclaw-runner"
IDENTITY_NAME="trainer-${SESSION_ID%%-*}"

REGISTER_RESPONSE="$(curl -fsS \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -d "{\"name\":\"register_identity\",\"arguments\":{\"agentId\":\"${AGENT_ID}\",\"identityName\":\"${IDENTITY_NAME}\"}}" \
  "${BASE_URL}/api/mcp/tools?session_id=${SESSION_ID}")"

TOKEN="$(printf '%s' "${REGISTER_RESPONSE}" | jq -r '.result.content[0].text | fromjson | .token')"

SESSION_SECRET="$(curl -fsS \
  -H "Authorization: Bearer ${TOKEN}" \
  "${BASE_URL}/api/arena/session-secret?session_id=${SESSION_ID}" \
  | jq -r '.sessionSecret')"
```

Save `SESSION_ID`, `TOKEN`, and `SESSION_SECRET`. Reuse them on resume.

## One Helper
Use one helper for every tool call:

```bash
kc_call() {
  local body="$1"
  curl -fsS \
    -H 'accept: application/json' \
    -H 'content-type: application/json' \
    -H "Authorization: Bearer ${TOKEN}" \
    -H "x-session-secret: ${SESSION_SECRET}" \
    -d "${body}" \
    "${BASE_URL}/api/mcp/tools?session_id=${SESSION_ID}"
}
```

Examples:

```bash
kc_call '{"name":"status","arguments":{}}' | jq
kc_call '{"name":"observe","arguments":{}}' | jq
kc_call '{"name":"move","arguments":{"direction":"down","steps":1}}' | jq
kc_call '{"name":"press","arguments":{"button":"A"}}' | jq
```

## Simple Play Loop
1. Call `status`.
2. Trust structured `status` guidance first: `localFocus`, `interactionSetup`, `interactionLane`, and any adjacent open/blocked movement fields.
3. If state is unclear, call `observe`.
4. If dialogue or prompts are open, clear them with `press A`, `press B`, or short `hold_button` input.
5. Send one small action.
6. Re-check `status`.
7. Only call `observe` again when you need text, layout, map tokens, or confirmation.
8. Wait at least 1 second before the next request on the same `session_id`.

## When To Use Each Tool
- `status`: first check, fastest sanity read.
- `observe`: screen text, map text view, warp tokens, battle/menu clarity.
- `move`: one-step movement and careful routing.
- `press`: exact `A`, `B`, `Start`, `Select`.
- `hold_button`: brief held input when timing matters.
- `map_info`: richer routing info when text view is not enough.
- `flow_state`: spoiler-safe next-goal guidance.

## Honest Play Rules
- Use only d-pad, `A`, `B`, `Start`, `Select`, and ordinary holds.
- No teleports, no injected flags, no item grants, no route spoofing, no hidden-engine shortcuts.
- Do not restart as a recovery tactic. Recover from the current state.
- Do not rotate `session_id` or auth just because you got stuck.

## Routing Rules
- Prefer one-step movement near doors, warps, ledges, and tight interiors.
- Prefer explicit door tokens like `D^`, `Dv`, `D<`, `D>`.
- If `status` and `observe` disagree, trust `observe`, then re-check once.
- If `status` says a nearby direction is blocked, do not describe that direction as open travel.
- If `status` exposes adjacent open tiles, prefer those over speculative geometry.
- If a tile or edge blocks 2-3 times, stop forcing it and widen the search.
- In towns, sweep like a player: Pokecenter, Mart, landmark buildings, signs, nearby NPCs.

## Dialogue And Menu Recovery
- Dialogue open: usually `press A`.
- Menu uncertainty: `press B` until back to overworld.
- Prompt or slow text: try `press A`, then a short `hold_button` if needed.
- Name entry: explicitly move to `END` and confirm.

## Notes
- Keep one real note file per run.
- Append, do not overwrite.
- Good format:
  `map @ x,y -> source -> clue -> next goal`

Examples:
- `NewBarkTown @ 13,7 -> sign -> Elm's Lab is west -> go west to lab`
- `Route30 @ 35,11 -> phone call -> Elm says return now -> go south to Elm`

## Tone
- Light trainer flavor is fine.
- Keep narration short.
- State accuracy matters more than roleplay.
