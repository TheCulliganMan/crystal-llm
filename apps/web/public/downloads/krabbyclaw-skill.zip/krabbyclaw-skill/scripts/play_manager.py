#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Non-cheating helpers for status-gated MCP play management."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any

from mcp_tools_call import (
    DEFAULT_SESSION_STORE,
    call_tool,
    default_identity_name,
    ensure_agent_session,
    resolve_session_store_path,
)

DEFAULT_BASE_URL = "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/mcp/tools"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("KRABBYCLAW_AGENT_ID", "default-agent"),
        help="Stable agent id used to load/save persistent session auth.",
    )
    parser.add_argument(
        "--session-store",
        default=os.environ.get("KRABBYCLAW_SESSION_STORE", DEFAULT_SESSION_STORE),
        help="Path to persistent agent session store JSON.",
    )
    parser.add_argument("--session-id", default="")
    parser.add_argument(
        "--identity-name",
        default="",
        help="Optional register_identity name (default: saved or UUID-derived).",
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("KRABBYCLAW_IDENTITY_TOKEN", ""),
        help="Identity token from register_identity; sent as Bearer token.",
    )
    parser.add_argument(
        "--session-secret",
        default=os.environ.get("KRABBYCLAW_SESSION_SECRET", ""),
        help="Session secret from /api/arena/session-secret.",
    )
    parser.add_argument(
        "--mcp-token",
        default=os.environ.get("KRABBYCLAW_MCP_TOKEN", ""),
        help="Optional static MCP token for deployments protected by KRABBYCLAW_MCP_TOKEN.",
    )
    parser.add_argument(
        "--move",
        default="",
        help="Direction and optional times, e.g. up or up:2",
    )
    parser.add_argument(
        "--press",
        default="",
        help="Button and optional times, e.g. a or a:2",
    )
    parser.add_argument(
        "--macro",
        default="",
        help="Macro name for execute_macro (advance_dialog|mash_a|interact|approach_target)",
    )
    parser.add_argument(
        "--target-token",
        default="",
        help="Required when --macro=approach_target",
    )
    parser.add_argument(
        "--recover-attempts",
        type=int,
        default=3,
        help="How many bounded recovery attempts to run before action (default: 3).",
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Print compact JSON instead of pretty JSON.",
    )
    return parser.parse_args()


def parse_status_text(status_response: dict[str, Any]) -> dict[str, Any]:
    result = status_response.get("result")
    if not isinstance(result, dict):
        raise SystemExit("status response missing result object.")
    content = result.get("content")
    if not isinstance(content, list) or not content:
        raise SystemExit("status response missing content array.")
    entry = content[0]
    if not isinstance(entry, dict) or not isinstance(entry.get("text"), str):
        raise SystemExit("status response missing text content.")
    try:
        parsed = json.loads(entry["text"])
    except json.JSONDecodeError as exc:
        raise SystemExit("status content is not valid JSON.") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("status content is not a JSON object.")
    return parsed


def status_needs_recovery(status: dict[str, Any]) -> bool:
    return (
        not bool(status.get("can_move"))
        or bool(status.get("in_dialog"))
        or bool(status.get("prompt_pending"))
        or bool(status.get("textbox_open"))
        or bool(status.get("movement_locked"))
        or bool(status.get("script_busy"))
    )


def parse_observe_status(observe_response: dict[str, Any]) -> dict[str, Any]:
    result = observe_response.get("result")
    if not isinstance(result, dict):
        raise SystemExit("observe response missing result object.")
    snapshot = result.get("snapshot")
    if isinstance(snapshot, dict):
        status = snapshot.get("status")
        if isinstance(status, dict):
            return status
    content = result.get("content")
    if isinstance(content, list):
        for entry in content:
            if not isinstance(entry, dict):
                continue
            text = entry.get("text")
            if not isinstance(text, str):
                continue
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict) and isinstance(parsed.get("status"), dict):
                return parsed["status"]
    raise SystemExit("observe response missing parseable status payload.")


def merge_status_prefer_observe(
    *,
    status: dict[str, Any],
    observe_status: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    merged = dict(status)
    conflicts: list[str] = []
    keys_to_prefer = [
        "mode",
        "in_menu",
        "menu",
        "in_dialog",
        "textbox_open",
        "text_box_open",
        "prompt_pending",
        "movement_locked",
        "script_busy",
        "can_move",
        "map",
        "coords",
        "facing",
    ]
    for key in keys_to_prefer:
        if key in observe_status:
            if key in status and status.get(key) != observe_status.get(key):
                conflicts.append(key)
            merged[key] = observe_status[key]
    return merged, conflicts


def observe_contains_name_entry(observe_response: dict[str, Any]) -> bool:
    result = observe_response.get("result")
    if not isinstance(result, dict):
        return False
    content = result.get("content")
    if not isinstance(content, list):
        return False
    for entry in content:
        if not isinstance(entry, dict):
            continue
        text = entry.get("text")
        if isinstance(text, str) and "NAME ENTRY" in text:
            return True
    return False


def extract_name_entry_cursor(
    observe_response: dict[str, Any],
) -> tuple[int, int] | None:
    result = observe_response.get("result")
    if not isinstance(result, dict):
        return None
    content = result.get("content")
    if not isinstance(content, list):
        return None
    pattern = re.compile(r"CURSOR:\s*row\s*(\d+)\s*col\s*(\d+)")
    for entry in content:
        if not isinstance(entry, dict):
            continue
        text = entry.get("text")
        if not isinstance(text, str):
            continue
        match = pattern.search(text)
        if match is None:
            continue
        return int(match.group(1)), int(match.group(2))
    return None


def call_observe(
    *,
    base_url: str,
    session_id: str,
    token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    return call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="observe",
        tool_args={},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )


def resolve_name_entry_menu(
    *,
    base_url: str,
    session_id: str,
    token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    observe_before = call_observe(
        base_url=base_url,
        session_id=session_id,
        token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    if not observe_contains_name_entry(observe_before):
        return {
            "resolved": False,
            "reason": "name_entry_not_detected",
            "calls": [],
        }
    cursor = extract_name_entry_cursor(observe_before) or (0, 0)
    row, col = cursor
    target_row = 4
    target_col = 8
    calls: list[dict[str, Any]] = []
    if row < target_row:
        calls.append(
            call_tool(
                base_url=base_url,
                session_id=session_id,
                tool_name="move",
                tool_args={"direction": "down", "times": target_row - row},
                identity_token=token,
                session_secret=session_secret,
                mcp_token=mcp_token,
            )
        )
    elif row > target_row:
        calls.append(
            call_tool(
                base_url=base_url,
                session_id=session_id,
                tool_name="move",
                tool_args={"direction": "up", "times": row - target_row},
                identity_token=token,
                session_secret=session_secret,
                mcp_token=mcp_token,
            )
        )
    if col < target_col:
        calls.append(
            call_tool(
                base_url=base_url,
                session_id=session_id,
                tool_name="move",
                tool_args={"direction": "right", "times": target_col - col},
                identity_token=token,
                session_secret=session_secret,
                mcp_token=mcp_token,
            )
        )
    elif col > target_col:
        calls.append(
            call_tool(
                base_url=base_url,
                session_id=session_id,
                tool_name="move",
                tool_args={"direction": "left", "times": col - target_col},
                identity_token=token,
                session_secret=session_secret,
                mcp_token=mcp_token,
            )
        )
    calls.append(
        call_tool(
            base_url=base_url,
            session_id=session_id,
            tool_name="press",
            tool_args={"button": "a", "times": 1},
            identity_token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
    )
    calls.append(
        call_tool(
            base_url=base_url,
            session_id=session_id,
            tool_name="execute_macro",
            tool_args={"macro": "advance_dialog", "max_presses": 4},
            identity_token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
    )
    observe_after = call_observe(
        base_url=base_url,
        session_id=session_id,
        token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    return {
        "resolved": not observe_contains_name_entry(observe_after),
        "reason": "attempted_end_selection",
        "cursor_before": {"row": cursor[0], "col": cursor[1]},
        "calls": calls,
        "observe_after": observe_after,
    }


def build_checkpoint(status: dict[str, Any]) -> dict[str, Any]:
    coords = status.get("coords")
    coords_obj = coords if isinstance(coords, dict) else {}
    party_summary = status.get("party_summary")
    party_summary_obj = party_summary if isinstance(party_summary, dict) else {}
    return {
        "map": status.get("map"),
        "coords": {
            "x": coords_obj.get("x"),
            "y": coords_obj.get("y"),
        },
        "facing": status.get("facing"),
        "mode": status.get("mode"),
        "badges_count": status.get("badges_count"),
        "party_count": party_summary_obj.get("count"),
        "lead_species": party_summary_obj.get("lead_species"),
        "lead_level": party_summary_obj.get("lead_level"),
        "can_move": status.get("can_move"),
    }


def parse_control(raw: str, *, allowed: set[str]) -> tuple[str, int]:
    if ":" in raw:
        value, times_raw = raw.split(":", 1)
        try:
            times = int(times_raw)
        except ValueError as exc:
            raise SystemExit(
                f"Invalid count in '{raw}'. Use name or name:<count>."
            ) from exc
    else:
        value = raw
        times = 1
    value = value.strip().lower()
    if value not in allowed:
        raise SystemExit(f"Invalid value '{value}'. Allowed: {sorted(allowed)}")
    if times < 1:
        raise SystemExit("Count must be >= 1.")
    return value, times


def build_action(args: argparse.Namespace) -> tuple[str, dict[str, Any]]:
    picks = [bool(args.move), bool(args.press), bool(args.macro)]
    if sum(picks) != 1:
        raise SystemExit("Exactly one of --move, --press, or --macro is required.")

    if args.move:
        direction, times = parse_control(
            args.move, allowed={"up", "down", "left", "right"}
        )
        return "move", {"direction": direction, "times": times}

    if args.press:
        button, times = parse_control(args.press, allowed={"a", "b", "start", "select"})
        return "press", {"button": button, "times": times}

    macro = args.macro.strip()
    if not macro:
        raise SystemExit("--macro cannot be empty.")
    payload: dict[str, Any] = {"macro": macro}
    if macro == "approach_target":
        if not args.target_token.strip():
            raise SystemExit("--target-token is required when --macro=approach_target.")
        payload["target_token"] = args.target_token.strip()
    return "execute_macro", payload


def call_status(
    *,
    base_url: str,
    session_id: str,
    token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    return call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="status",
        tool_args={},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )


def run_recovery(
    *,
    base_url: str,
    session_id: str,
    token: str,
    session_secret: str,
    mcp_token: str,
    attempts: int,
) -> tuple[list[dict[str, Any]], dict[str, Any], list[str], dict[str, Any]]:
    if attempts < 0:
        raise SystemExit("--recover-attempts must be >= 0.")
    recovery_calls: list[dict[str, Any]] = []
    status = parse_status_text(
        call_status(
            base_url=base_url,
            session_id=session_id,
            token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
    )
    observe = call_observe(
        base_url=base_url,
        session_id=session_id,
        token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    name_entry_resolution = resolve_name_entry_menu(
        base_url=base_url,
        session_id=session_id,
        token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    if name_entry_resolution.get("resolved"):
        observe = call_observe(
            base_url=base_url,
            session_id=session_id,
            token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
    observe_status = parse_observe_status(observe)
    merged_status, initial_conflicts = merge_status_prefer_observe(
        status=status, observe_status=observe_status
    )
    conflicts = list(initial_conflicts)
    for _ in range(attempts):
        if not status_needs_recovery(merged_status):
            break
        call = call_tool(
            base_url=base_url,
            session_id=session_id,
            tool_name="execute_macro",
            tool_args={"macro": "advance_dialog", "max_presses": 8},
            identity_token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
        recovery_calls.append(call)
        status = parse_status_text(
            call_status(
                base_url=base_url,
                session_id=session_id,
                token=token,
                session_secret=session_secret,
                mcp_token=mcp_token,
            )
        )
        observe = call_observe(
            base_url=base_url,
            session_id=session_id,
            token=token,
            session_secret=session_secret,
            mcp_token=mcp_token,
        )
        observe_status = parse_observe_status(observe)
        merged_status, loop_conflicts = merge_status_prefer_observe(
            status=status, observe_status=observe_status
        )
        conflicts.extend(loop_conflicts)
    return recovery_calls, merged_status, conflicts, name_entry_resolution


def main() -> int:
    args = parse_args()
    auth = ensure_agent_session(
        base_url=args.base_url,
        agent_id=args.agent_id,
        store_path=resolve_session_store_path(args.session_store),
        session_id=args.session_id.strip(),
        identity_name=args.identity_name.strip() or default_identity_name(),
        token=args.token.strip(),
        session_secret=args.session_secret.strip(),
        mcp_token=args.mcp_token.strip(),
    )
    tool_name, tool_args = build_action(args)
    recovery_calls, status_before, status_conflicts, name_entry_resolution = (
        run_recovery(
            base_url=args.base_url,
            session_id=auth["sessionId"],
            token=auth["token"],
            session_secret=auth["sessionSecret"],
            mcp_token=args.mcp_token.strip(),
            attempts=args.recover_attempts,
        )
    )
    action_response = call_tool(
        base_url=args.base_url,
        session_id=auth["sessionId"],
        tool_name=tool_name,
        tool_args=tool_args,
        identity_token=auth["token"],
        session_secret=auth["sessionSecret"],
        mcp_token=args.mcp_token.strip(),
    )
    final_status = parse_status_text(
        call_status(
            base_url=args.base_url,
            session_id=auth["sessionId"],
            token=auth["token"],
            session_secret=auth["sessionSecret"],
            mcp_token=args.mcp_token.strip(),
        )
    )
    final_observe = call_observe(
        base_url=args.base_url,
        session_id=auth["sessionId"],
        token=auth["token"],
        session_secret=auth["sessionSecret"],
        mcp_token=args.mcp_token.strip(),
    )
    observe_status_after = parse_observe_status(final_observe)
    merged_final_status, final_conflicts = merge_status_prefer_observe(
        status=final_status, observe_status=observe_status_after
    )
    checkpoint = build_checkpoint(merged_final_status)
    output = {
        "ok": True,
        "agentId": auth["agentId"],
        "sessionId": auth["sessionId"],
        "identityName": auth["identityName"],
        "playerId": auth["playerId"],
        "storePath": auth["storePath"],
        "bootstrapped": auth["bootstrapped"],
        "recovery_attempts_used": len(recovery_calls),
        "status_before_action": status_before,
        "status_source_conflicts_before_action": status_conflicts,
        "name_entry_resolution": name_entry_resolution,
        "action": {"tool": tool_name, "arguments": tool_args},
        "action_response": action_response,
        "status_after_action": merged_final_status,
        "status_source_conflicts_after_action": final_conflicts,
        "checkpoint": checkpoint,
    }
    if args.compact:
        print(json.dumps(output, separators=(",", ":"), ensure_ascii=True))
    else:
        print(json.dumps(output, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
