#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Call the deployed KrabbyClaw MCP tools HTTP API from Python."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any

DEFAULT_KRABBYCLAW_HOST = "https://pokecrystal-python-pokecrystal-ts.vercel.app"
DEFAULT_BASE_URL = f"{DEFAULT_KRABBYCLAW_HOST}/api/mcp/tools"
DEFAULT_SESSION_STORE = "~/.krabbyclaw-agent-sessions.json"
MIN_REQUEST_INTERVAL_SECONDS = 1.0
_LAST_TOOL_CALL_AT: dict[str, float] = {}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("KRABBYCLAW_AGENT_ID", "default-agent"),
        help="Stable agent id used to load/save persistent session auth.",
    )
    parser.add_argument(
        "--session-store",
        default=os.environ.get("KRABBYCLAW_SESSION_STORE", DEFAULT_SESSION_STORE),
        help="Path to persistent agent session store JSON.",
    )
    parser.add_argument("--session-id", default="")
    parser.add_argument("--tool", default="")
    parser.add_argument(
        "--args", default="{}", help="JSON object string for tool arguments."
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("KRABBYCLAW_IDENTITY_TOKEN", ""),
        help="Identity token from register_identity; sent as Bearer token.",
    )
    parser.add_argument(
        "--session-secret",
        default=os.environ.get("KRABBYCLAW_SESSION_SECRET", ""),
        help="Session secret from /api/arena/session-secret.",
    )
    parser.add_argument(
        "--mcp-token",
        default=os.environ.get("KRABBYCLAW_MCP_TOKEN", ""),
        help="Optional static MCP token for deployments protected by KRABBYCLAW_MCP_TOKEN.",
    )
    parser.add_argument(
        "--issue-session-secret",
        action="store_true",
        help="Call /api/arena/session-secret for --session-id and print the JSON response.",
    )
    parser.add_argument(
        "--one-shot-play",
        action="store_true",
        help="Bootstrap auth and run a short playable sequence on the selected session.",
    )
    parser.add_argument(
        "--identity-name",
        default="",
        help="Name passed to register_identity in --one-shot-play mode (default: unique UUID-derived name).",
    )
    parser.add_argument(
        "--dialog-presses",
        type=int,
        default=2,
        help="Max presses for advance_dialog in --one-shot-play mode.",
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Print compact JSON instead of pretty JSON.",
    )
    return parser.parse_args()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def resolve_session_store_path(raw_path: str) -> Path:
    return Path(raw_path).expanduser().resolve()


def _load_session_store(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Session store is not valid JSON: {path}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit(f"Session store root must be a JSON object: {path}")
    return parsed


def _save_session_store(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(payload, indent=2, ensure_ascii=True) + "\n"
    temp_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temp_path.write_text(serialized, encoding="utf-8")
        os.replace(temp_path, path)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def load_agent_session(*, store_path: Path, agent_id: str) -> dict[str, str]:
    store = _load_session_store(store_path)
    agents = store.get("agents")
    if not isinstance(agents, dict):
        return {}
    data = agents.get(agent_id)
    if not isinstance(data, dict):
        return {}
    result: dict[str, str] = {}
    for key in ("sessionId", "identityName", "playerId", "token", "sessionSecret"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            result[key] = value.strip()
    return result


def save_agent_session(
    *,
    store_path: Path,
    agent_id: str,
    session_id: str,
    identity_name: str,
    player_id: str,
    token: str,
    session_secret: str,
) -> None:
    store = _load_session_store(store_path)
    agents = store.get("agents")
    if not isinstance(agents, dict):
        agents = {}
    agents[agent_id] = {
        "sessionId": session_id,
        "identityName": identity_name,
        "playerId": player_id,
        "token": token,
        "sessionSecret": session_secret,
        "updatedAt": utc_now_iso(),
    }
    store["agents"] = agents
    _save_session_store(store_path, store)


def parse_tool_args(raw: str) -> dict[str, Any]:
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"--args is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("--args must decode to a JSON object.")
    return parsed


def build_url(base_url: str, session_id: str) -> str:
    if not session_id:
        return base_url
    parts = urllib.parse.urlsplit(base_url)
    query = urllib.parse.parse_qs(parts.query, keep_blank_values=True)
    query["session_id"] = [session_id]
    next_query = urllib.parse.urlencode(query, doseq=True)
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, parts.path, next_query, parts.fragment)
    )


def resolve_session_secret_url(base_url: str, session_id: str) -> str:
    if not session_id:
        raise SystemExit("--session-id is required when issuing a session secret.")
    parts = urllib.parse.urlsplit(base_url)
    query = urllib.parse.urlencode({"session_id": session_id})
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, "/api/arena/session-secret", query, "")
    )


def _request_json(request: urllib.request.Request) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code}: {raw}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Network error: {exc}") from exc

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Response is not valid JSON: {raw}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("Response is valid JSON but not an object.")
    return parsed


def issue_session_secret(
    *, base_url: str, session_id: str, identity_token: str
) -> dict[str, Any]:
    if not identity_token:
        raise SystemExit(
            "--token (identity token) is required to issue session secret."
        )
    url = resolve_session_secret_url(base_url, session_id)
    headers = {"authorization": f"Bearer {identity_token}"}
    request = urllib.request.Request(url, headers=headers, method="GET")
    return _request_json(request)


def call_tool(
    *,
    base_url: str,
    session_id: str,
    tool_name: str,
    tool_args: dict[str, Any],
    identity_token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    now = time.time()
    last_call = _LAST_TOOL_CALL_AT.get(session_id)
    if last_call is not None:
        wait_seconds = MIN_REQUEST_INTERVAL_SECONDS - (now - last_call)
        if wait_seconds > 0:
            time.sleep(wait_seconds)
    url = build_url(base_url, session_id)
    payload = {"tool": tool_name, "arguments": tool_args}
    body = json.dumps(payload).encode("utf-8")
    headers = {"content-type": "application/json"}
    if identity_token:
        headers["authorization"] = f"Bearer {identity_token}"
    if session_secret:
        headers["x-session-secret"] = session_secret
    if mcp_token:
        headers["x-mcp-token"] = mcp_token

    request = urllib.request.Request(url, data=body, headers=headers, method="POST")
    for attempt in range(3):
        try:
            response = _request_json(request)
            _LAST_TOOL_CALL_AT[session_id] = time.time()
            return response
        except SystemExit as exc:
            message = str(exc).lower()
            is_rate_limited = "rate limit" in message and (
                "http 429" in message or "http 500" in message
            )
            if not is_rate_limited or attempt == 2:
                raise
            time.sleep(1.0 * (2**attempt))
    raise SystemExit("Unreachable retry state in call_tool.")


def parse_registration(response: dict[str, Any]) -> dict[str, str]:
    result = response.get("result")
    if not isinstance(result, dict):
        raise SystemExit("register_identity response missing result object.")
    content = result.get("content")
    if not isinstance(content, list):
        raise SystemExit("register_identity response missing content array.")
    text_entry = next(
        (
            entry
            for entry in content
            if isinstance(entry, dict)
            and entry.get("type") == "text"
            and isinstance(entry.get("text"), str)
            and entry.get("text")
        ),
        None,
    )
    if text_entry is None:
        raise SystemExit("register_identity response did not include text content.")
    try:
        parsed = json.loads(text_entry["text"])
    except json.JSONDecodeError as exc:
        raise SystemExit("register_identity text content is not valid JSON.") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("register_identity text content is not a JSON object.")
    player_id = parsed.get("playerId")
    token = parsed.get("token")
    if not isinstance(player_id, str) or not player_id.strip():
        raise SystemExit("register_identity payload missing playerId.")
    if not isinstance(token, str) or not token.strip():
        raise SystemExit("register_identity payload missing token.")
    return {"playerId": player_id.strip(), "token": token.strip()}


def run_one_shot_play(
    *,
    base_url: str,
    session_id: str,
    player_id: str,
    token: str,
    session_secret: str,
    dialog_presses: int,
    mcp_token: str,
) -> dict[str, Any]:
    if not session_id:
        raise SystemExit("--session-id is required for --one-shot-play.")
    if dialog_presses < 1:
        raise SystemExit("--dialog-presses must be at least 1.")

    observe_before = call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="observe",
        tool_args={},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    advance_dialog = call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="execute_macro",
        tool_args={"macro": "advance_dialog", "max_presses": dialog_presses},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    status = call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="status",
        tool_args={},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )
    observe_after = call_tool(
        base_url=base_url,
        session_id=session_id,
        tool_name="observe",
        tool_args={},
        identity_token=token,
        session_secret=session_secret,
        mcp_token=mcp_token,
    )

    return {
        "ok": True,
        "sessionId": session_id,
        "playerId": player_id,
        "token": token,
        "sessionSecret": session_secret,
        "steps": {
            "observe_before": observe_before,
            "advance_dialog": advance_dialog,
            "status": status,
            "observe_after": observe_after,
        },
    }


def default_identity_name() -> str:
    return f"trainer-{uuid.uuid4().hex[:8]}"


def ensure_agent_session(
    *,
    base_url: str,
    agent_id: str,
    store_path: Path,
    session_id: str,
    identity_name: str,
    token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    agent = agent_id.strip()
    if not agent:
        raise SystemExit("--agent-id cannot be empty.")

    saved = load_agent_session(store_path=store_path, agent_id=agent)
    requested_session_id = session_id.strip()
    saved_session_id = saved.get("sessionId", "").strip()
    resolved_session_id = requested_session_id or saved_session_id or str(uuid.uuid4())
    resolved_identity_name = (
        identity_name.strip()
        or saved.get("identityName", "").strip()
        or default_identity_name()
    )
    use_saved_auth = (
        not requested_session_id or requested_session_id == saved_session_id
    )
    resolved_player_id = saved.get("playerId", "").strip() if use_saved_auth else ""
    saved_token = saved.get("token", "").strip() if use_saved_auth else ""
    saved_session_secret = (
        saved.get("sessionSecret", "").strip() if use_saved_auth else ""
    )
    resolved_token = token.strip() or saved_token
    resolved_session_secret = session_secret.strip() or saved_session_secret
    bootstrapped = False

    if not resolved_token:
        register_response = call_tool(
            base_url=base_url,
            session_id=resolved_session_id,
            tool_name="register_identity",
            tool_args={"name": resolved_identity_name},
            identity_token="",
            session_secret="",
            mcp_token=mcp_token,
        )
        registration = parse_registration(register_response)
        resolved_token = registration["token"]
        resolved_player_id = registration["playerId"]
        bootstrapped = True

    if not resolved_session_secret:
        session_secret_response = issue_session_secret(
            base_url=base_url,
            session_id=resolved_session_id,
            identity_token=resolved_token,
        )
        session_secret_value = session_secret_response.get("sessionSecret")
        if (
            not isinstance(session_secret_value, str)
            or not session_secret_value.strip()
        ):
            raise SystemExit("session-secret response missing sessionSecret.")
        resolved_session_secret = session_secret_value.strip()
        bootstrapped = True

    save_agent_session(
        store_path=store_path,
        agent_id=agent,
        session_id=resolved_session_id,
        identity_name=resolved_identity_name,
        player_id=resolved_player_id,
        token=resolved_token,
        session_secret=resolved_session_secret,
    )

    return {
        "agentId": agent,
        "sessionId": resolved_session_id,
        "identityName": resolved_identity_name,
        "playerId": resolved_player_id,
        "token": resolved_token,
        "sessionSecret": resolved_session_secret,
        "bootstrapped": bootstrapped,
        "storePath": str(store_path),
    }


def main() -> int:
    args = parse_args()
    store_path = resolve_session_store_path(args.session_store)
    if args.one_shot_play:
        auth = ensure_agent_session(
            base_url=args.base_url,
            agent_id=args.agent_id,
            store_path=store_path,
            session_id=args.session_id.strip(),
            identity_name=args.identity_name.strip() or default_identity_name(),
            token=args.token.strip(),
            session_secret=args.session_secret.strip(),
            mcp_token=args.mcp_token.strip(),
        )
        response = run_one_shot_play(
            base_url=args.base_url,
            session_id=auth["sessionId"],
            player_id=auth["playerId"],
            token=auth["token"],
            session_secret=auth["sessionSecret"],
            dialog_presses=args.dialog_presses,
            mcp_token=args.mcp_token.strip(),
        )
        response["agentId"] = auth["agentId"]
        response["storePath"] = auth["storePath"]
        response["bootstrapped"] = auth["bootstrapped"]
    elif args.issue_session_secret:
        auth = ensure_agent_session(
            base_url=args.base_url,
            agent_id=args.agent_id,
            store_path=store_path,
            session_id=args.session_id.strip(),
            identity_name=args.identity_name.strip() or default_identity_name(),
            token=args.token.strip(),
            session_secret=args.session_secret.strip(),
            mcp_token=args.mcp_token.strip(),
        )
        response = {
            "ok": True,
            "agentId": auth["agentId"],
            "sessionId": auth["sessionId"],
            "playerId": auth["playerId"],
            "token": auth["token"],
            "sessionSecret": auth["sessionSecret"],
            "storePath": auth["storePath"],
            "bootstrapped": auth["bootstrapped"],
        }
    else:
        if not args.tool.strip():
            raise SystemExit(
                "--tool is required unless --issue-session-secret or --one-shot-play is used."
            )
        auth = ensure_agent_session(
            base_url=args.base_url,
            agent_id=args.agent_id,
            store_path=store_path,
            session_id=args.session_id.strip(),
            identity_name=args.identity_name.strip() or default_identity_name(),
            token=args.token.strip(),
            session_secret=args.session_secret.strip(),
            mcp_token=args.mcp_token.strip(),
        )
        tool_args = parse_tool_args(args.args)
        response = call_tool(
            base_url=args.base_url,
            session_id=auth["sessionId"],
            tool_name=args.tool.strip(),
            tool_args=tool_args,
            identity_token=auth["token"],
            session_secret=auth["sessionSecret"],
            mcp_token=args.mcp_token.strip(),
        )
    if args.compact:
        print(json.dumps(response, separators=(",", ":"), ensure_ascii=True))
    else:
        print(json.dumps(response, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
