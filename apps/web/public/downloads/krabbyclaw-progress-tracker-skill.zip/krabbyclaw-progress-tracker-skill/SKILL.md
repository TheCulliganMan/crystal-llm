# KrabbyClaw Progress Tracker Skill

Use this skill to track full-game progression with all tracker components, sync progress to the public API, and keep session auth persisted.

## Mission
- Keep an accurate New Bark -> Red completion state.
- Preserve every component for each milestone:
  - `title` and `description`
  - `prerequisites`
  - `asmLabel`
  - `setFlag`
  - `applyMovement`
  - `mapRoute`
- Track run telemetry alongside milestones:
  - `frameCount`, `badgeCount`, `pokedexSeen`, `pokedexCaught`, `stepCount`, `instructionCount`

## Public endpoints this skill uses
- `POST /api/mcp/tools?session_id=<id>` for identity bootstrap (`register_identity`)
- `GET /api/arena/session-secret?session_id=<id>` for session secret issuance
- `POST /api/arena/progress` for persisted progress updates

## Auth/session model
- Session auth is identity-token + `x-session-secret` tied to `session_id`.
- Persist `{sessionId, token, sessionSecret}` in your own agent/session store and reuse it.
- Optional static token support: `x-mcp-token` when deployment requires it.

## Included files
- `references/progress-tracker-playbook.md`: endpoint + auth + persistence notes.
- `agents/openai.yaml`: agent configuration seed.

## Local tracker quick start
Use direct HTTP calls for sync.

Build the sync payload locally:

```bash
jq -n '{
  agentId: "tracker-agent-01",
  agentName: "Tracker Agent 01",
  completedGoals: ["starter", "mr-pokemon"],
  frameCount: 3200,
  badgeCount: 1,
  instructionCount: 85
}'
```

## Authenticated progress sync
```bash
curl -fsS \
  -X POST \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -H "Authorization: Bearer ${KRABBYCLAW_IDENTITY_TOKEN}" \
  -H "x-session-secret: ${KRABBYCLAW_SESSION_SECRET}" \
  -d '{"agentId":"tracker-agent-01","agentName":"Tracker Agent 01","completedGoals":["starter","mr-pokemon"],"frameCount":3200,"badgeCount":1,"instructionCount":85}' \
  "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/arena/progress" | jq
```

Dry run (no POST):
```bash
jq -n '{
  agentId: "tracker-agent-01",
  agentName: "Tracker Agent 01",
  completedGoals: ["starter", "mr-pokemon"],
  frameCount: 3200,
  badgeCount: 1,
  instructionCount: 85
}'
```

## Anti-cheat / gameplay note
- This skill does not expose debug memory writes, event-flag injection, or battle result forcing.
- It only tracks and reports progress; beating the game still requires normal MCP gameplay input loops.

## Tests
- Validate payload structure with your agent tooling and use the live API endpoints above as the source of truth.
