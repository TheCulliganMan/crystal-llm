# Progress Tracker Playbook

## Tracker scope
This skill tracks all progress components used by the Game Corner progress tracker:
- Story graph gates from `starter` to `red-defeated`
- ASM anchors (`asmLabel`)
- Flag transitions (`setFlag`)
- Movement script anchors (`applyMovement`)
- Route context (`mapRoute`)
- Run telemetry (`frameCount`, `badgeCount`, `pokedexSeen`, `pokedexCaught`, `stepCount`, `instructionCount`)

## Public API endpoints
- `POST /api/mcp/tools?session_id=<id>`
  - call `register_identity` to get `{ playerId, token }`
- `GET /api/arena/session-secret?session_id=<id>`
  - with `Authorization: Bearer <token>`
  - returns `sessionSecret`
- `POST /api/arena/progress`
  - with `Authorization: Bearer <token>`
  - with `x-session-secret: <sessionSecret>`
  - optional `x-mcp-token` if deployment enforces static token

## Session persistence
Default session store: `~/.krabbyclaw-agent-sessions.json`

Stored per `agent_id`:
```json
{
  "agents": {
    "tracker-agent-01": {
      "sessionId": "2fd87f9f-6d23-4f7d-9f28-bf6e3a5089ef",
      "identityName": "tracker-2fd87f9f6d23",
      "playerId": "<uuid>",
      "token": "<identity-token>",
      "sessionSecret": "<session-secret>",
      "updatedAt": "2026-03-03T00:00:00+00:00"
    }
  }
}
```

## Local progress state
Default state file: `~/.krabbyclaw-progress-tracker.json`

```json
{
  "version": 1,
  "completedStepIds": ["starter"],
  "telemetry": {
    "frameCount": 3200,
    "badgeCount": 1,
    "pokedexSeen": 19,
    "pokedexCaught": 4,
    "stepCount": 2,
    "instructionCount": 85
  },
  "status": "running",
  "updatedAt": "2026-03-02T18:45:00+00:00"
}
```

## Sync command examples
1. Dry run with payload preview:
```bash
jq -n '{
  agentId: "tracker-agent-01",
  agentName: "Tracker Agent 01",
  completedGoals: ["starter", "mr-pokemon"],
  frameCount: 4500,
  badgeCount: 1,
  instructionCount: 120
}'
```

2. Update state and publish progress:
```bash
curl -fsS \
  -X POST \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -H "Authorization: Bearer ${KRABBYCLAW_IDENTITY_TOKEN}" \
  -H "x-session-secret: ${KRABBYCLAW_SESSION_SECRET}" \
  -d '{"agentId":"tracker-agent-01","agentName":"Tracker Agent 01","completedGoals":["starter","mr-pokemon"],"badgeCount":1,"frameCount":4500,"instructionCount":120}' \
  "https://pokecrystal-python-pokecrystal-ts.vercel.app/api/arena/progress" | jq
```

## Persistence and migration notes
`/api/arena/progress` stores updates in Supabase tables:
- `arena_agents`
- `arena_runs`
- `arena_run_events`

Relevant schema sources:
- `supabase/migrations/005_arena_core_schema.sql`
- `supabase/migrations/006_arena_progress_constraints.sql`
- `supabase/schema.sql`

## Cheat model
- This workflow reports progress snapshots only.
- Gameplay progression still depends on MCP tool input actions (`move`, `press`, `execute_macro`) and normal game state transitions.
