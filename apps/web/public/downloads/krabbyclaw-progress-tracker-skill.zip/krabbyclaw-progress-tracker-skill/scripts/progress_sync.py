#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Sync progress tracker state to the public /api/arena/progress endpoint."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any

import progress_tracker_manager as tracker

DEFAULT_HOST = "https://pokecrystal-python-pokecrystal-ts.vercel.app"
DEFAULT_SESSION_STORE = "~/.krabbyclaw-agent-sessions.json"
SESSION_ID_REGEX = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument(
        "--agent-id",
        default=os.environ.get("KRABBYCLAW_AGENT_ID", "progress-tracker-agent"),
        help="Stable agent id used to load/save persistent session auth.",
    )
    parser.add_argument(
        "--agent-name",
        default="",
        help="Agent display name for /api/arena/progress payload (required).",
    )
    parser.add_argument(
        "--session-store",
        default=os.environ.get("KRABBYCLAW_SESSION_STORE", DEFAULT_SESSION_STORE),
        help="Path to persistent session store JSON.",
    )
    parser.add_argument("--session-id", default="")
    parser.add_argument(
        "--identity-name",
        default="",
        help="Optional identity name used when registering a new identity.",
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("KRABBYCLAW_IDENTITY_TOKEN", ""),
        help="Existing identity token override.",
    )
    parser.add_argument(
        "--session-secret",
        default=os.environ.get("KRABBYCLAW_SESSION_SECRET", ""),
        help="Existing session secret override.",
    )
    parser.add_argument(
        "--mcp-token",
        default=os.environ.get("KRABBYCLAW_MCP_TOKEN", ""),
        help="Optional static token for token-protected deployments.",
    )
    parser.add_argument(
        "--state-file",
        default="~/.krabbyclaw-progress-tracker.json",
        help="Path to local progress tracker state file.",
    )
    parser.add_argument("--complete", action="append", default=[])
    parser.add_argument("--uncomplete", action="append", default=[])
    parser.add_argument(
        "--set-status",
        choices=("queued", "running", "completed", "failed", "cancelled"),
    )
    parser.add_argument("--frame-count", type=int)
    parser.add_argument("--badge-count", type=int)
    parser.add_argument("--pokedex-seen", type=int)
    parser.add_argument("--pokedex-caught", type=int)
    parser.add_argument("--step-count", type=int)
    parser.add_argument("--instruction-count", type=int)
    parser.add_argument("--queue", default="main")
    parser.add_argument("--runtime", default="mcp-http")
    parser.add_argument("--repo-url", default="")
    parser.add_argument("--model-url", default="")
    parser.add_argument("--note", default="")
    parser.add_argument("--error", default="")
    parser.add_argument(
        "--list-components",
        action="store_true",
        help="Include full story component metadata in output summary.",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Do not POST to /api/arena/progress."
    )
    parser.add_argument("--compact", action="store_true")
    return parser.parse_args()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def normalize_host(host: str) -> str:
    trimmed = host.strip()
    if not trimmed:
        raise SystemExit("--host must be non-empty.")
    if not trimmed.startswith("http://") and not trimmed.startswith("https://"):
        trimmed = f"https://{trimmed}"
    return trimmed.rstrip("/")


def resolve_session_store_path(raw_path: str) -> Path:
    return Path(raw_path).expanduser().resolve()


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"JSON file is invalid: {path}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit(f"JSON root must be an object: {path}")
    return parsed


def _save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8"
    )


def load_agent_session(*, store_path: Path, agent_id: str) -> dict[str, str]:
    store = _load_json(store_path)
    agents = store.get("agents")
    if not isinstance(agents, dict):
        return {}
    item = agents.get(agent_id)
    if not isinstance(item, dict):
        return {}
    result: dict[str, str] = {}
    for key in ("sessionId", "identityName", "playerId", "token", "sessionSecret"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            result[key] = value.strip()
    return result


def save_agent_session(
    *,
    store_path: Path,
    agent_id: str,
    session_id: str,
    identity_name: str,
    player_id: str,
    token: str,
    session_secret: str,
) -> None:
    store = _load_json(store_path)
    agents = store.get("agents")
    if not isinstance(agents, dict):
        agents = {}
    agents[agent_id] = {
        "sessionId": session_id,
        "identityName": identity_name,
        "playerId": player_id,
        "token": token,
        "sessionSecret": session_secret,
        "updatedAt": utc_now_iso(),
    }
    store["agents"] = agents
    _save_json(store_path, store)


def _request_json(request: urllib.request.Request) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code}: {raw}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Network error: {exc}") from exc

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Response is not valid JSON: {raw}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("JSON response root is not an object.")
    return parsed


def parse_register_identity_response(payload: dict[str, Any]) -> tuple[str, str]:
    result = payload.get("result")
    if not isinstance(result, dict):
        raise SystemExit("register_identity response missing result object.")
    content = result.get("content")
    if not isinstance(content, list) or not content:
        raise SystemExit("register_identity response missing content.")
    first = content[0]
    if not isinstance(first, dict):
        raise SystemExit("register_identity content[0] is invalid.")
    text = first.get("text")
    if not isinstance(text, str) or not text.strip():
        raise SystemExit("register_identity response missing text payload.")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise SystemExit("register_identity text payload is not valid JSON.") from exc
    if not isinstance(parsed, dict):
        raise SystemExit("register_identity text payload must be an object.")
    player_id = str(parsed.get("playerId") or "").strip()
    token = str(parsed.get("token") or "").strip()
    if not player_id or not token:
        raise SystemExit("register_identity payload missing playerId/token.")
    return player_id, token


def register_identity(
    *, host: str, session_id: str, identity_name: str
) -> tuple[str, str]:
    url = f"{host}/api/mcp/tools?session_id={urllib.parse.quote(session_id, safe='')}"
    body = json.dumps(
        {
            "tool": "register_identity",
            "arguments": {
                "name": identity_name,
            },
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        url,
        method="POST",
        data=body,
        headers={"content-type": "application/json"},
    )
    payload = _request_json(request)
    return parse_register_identity_response(payload)


def issue_session_secret(*, host: str, session_id: str, token: str) -> str:
    url = f"{host}/api/arena/session-secret?session_id={urllib.parse.quote(session_id, safe='')}"
    request = urllib.request.Request(
        url,
        method="GET",
        headers={"authorization": f"Bearer {token}"},
    )
    payload = _request_json(request)
    secret = str(payload.get("sessionSecret") or "").strip()
    if not secret:
        raise SystemExit("session-secret response missing sessionSecret.")
    return secret


def default_identity_name(session_id: str) -> str:
    compact = session_id.replace("-", "")
    return f"tracker-{compact[:12] or 'agent'}"


def ensure_agent_auth(
    *,
    host: str,
    session_store_path: Path,
    agent_id: str,
    requested_session_id: str,
    requested_identity_name: str,
    requested_token: str,
    requested_session_secret: str,
) -> dict[str, str]:
    stored = load_agent_session(store_path=session_store_path, agent_id=agent_id)
    session_id = (
        requested_session_id or stored.get("sessionId") or str(uuid.uuid4())
    ).strip()
    if not SESSION_ID_REGEX.match(session_id):
        raise SystemExit("Resolved session_id is invalid.")

    identity_name = (
        requested_identity_name
        or stored.get("identityName")
        or default_identity_name(session_id)
    ).strip()
    token = (requested_token or stored.get("token") or "").strip()
    session_secret = (
        requested_session_secret or stored.get("sessionSecret") or ""
    ).strip()
    player_id = (stored.get("playerId") or "").strip()

    if not token:
        player_id, token = register_identity(
            host=host, session_id=session_id, identity_name=identity_name
        )
    if not session_secret:
        session_secret = issue_session_secret(
            host=host, session_id=session_id, token=token
        )

    if not player_id:
        player_id = stored.get("playerId", "")

    save_agent_session(
        store_path=session_store_path,
        agent_id=agent_id,
        session_id=session_id,
        identity_name=identity_name,
        player_id=player_id,
        token=token,
        session_secret=session_secret,
    )

    return {
        "sessionId": session_id,
        "identityName": identity_name,
        "playerId": player_id,
        "token": token,
        "sessionSecret": session_secret,
    }


def apply_tracker_updates(
    state_file: Path, args: argparse.Namespace
) -> tuple[dict[str, Any], dict[str, Any]]:
    state = tracker.load_state(state_file)
    tracker_args = argparse.Namespace(
        complete=args.complete,
        uncomplete=args.uncomplete,
        set_status=args.set_status,
        frame_count=args.frame_count,
        badge_count=args.badge_count,
        pokedex_seen=args.pokedex_seen,
        pokedex_caught=args.pokedex_caught,
        step_count=args.step_count,
        instruction_count=args.instruction_count,
    )
    updated = tracker.apply_updates(state, tracker_args, tracker.STORY_STEPS)
    _save_json(state_file, updated)
    summary = tracker.build_summary(
        updated, tracker.STORY_STEPS, include_components=args.list_components
    )
    return updated, summary


def build_progress_payload(
    *,
    args: argparse.Namespace,
    tracker_state: dict[str, Any],
    summary: dict[str, Any],
    session_id: str,
) -> dict[str, Any]:
    progress_args = argparse.Namespace(
        session_id=session_id,
        agent_name=args.agent_name,
        queue=args.queue,
        runtime=args.runtime,
        repo_url=args.repo_url,
        model_url=args.model_url,
        note=args.note,
        error=args.error,
    )
    return tracker.build_progress_payload(progress_args, tracker_state, summary)


def post_progress(
    *,
    host: str,
    payload: dict[str, Any],
    token: str,
    session_secret: str,
    mcp_token: str,
) -> dict[str, Any]:
    url = f"{host}/api/arena/progress"
    headers = {
        "content-type": "application/json",
        "authorization": f"Bearer {token}",
        "x-session-secret": session_secret,
    }
    if mcp_token.strip():
        headers["x-mcp-token"] = mcp_token.strip()

    request = urllib.request.Request(
        url,
        method="POST",
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
    )
    return _request_json(request)


def print_json(payload: dict[str, Any], compact: bool) -> None:
    if compact:
        print(json.dumps(payload, separators=(",", ":"), ensure_ascii=True))
        return
    print(json.dumps(payload, indent=2, ensure_ascii=True))


def main() -> int:
    args = parse_args()
    host = normalize_host(args.host)

    state_file = tracker.resolve_state_file(args.state_file)
    session_store_path = resolve_session_store_path(args.session_store)
    if not args.agent_name.strip():
        raise SystemExit("--agent-name is required.")

    auth = ensure_agent_auth(
        host=host,
        session_store_path=session_store_path,
        agent_id=args.agent_id,
        requested_session_id=args.session_id,
        requested_identity_name=args.identity_name,
        requested_token=args.token,
        requested_session_secret=args.session_secret,
    )

    tracker_state, summary = apply_tracker_updates(state_file, args)
    progress_payload = build_progress_payload(
        args=args,
        tracker_state=tracker_state,
        summary=summary,
        session_id=auth["sessionId"],
    )

    output: dict[str, Any] = {
        "ok": True,
        "host": host,
        "auth": {
            "agentId": args.agent_id,
            "sessionId": auth["sessionId"],
            "identityName": auth["identityName"],
            "playerId": auth["playerId"],
            "sessionStore": str(session_store_path),
        },
        "summary": summary,
        "progressPayload": progress_payload,
        "dryRun": args.dry_run,
    }

    if not args.dry_run:
        output["progressResponse"] = post_progress(
            host=host,
            payload=progress_payload,
            token=auth["token"],
            session_secret=auth["sessionSecret"],
            mcp_token=args.mcp_token,
        )

    print_json(output, compact=args.compact)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
