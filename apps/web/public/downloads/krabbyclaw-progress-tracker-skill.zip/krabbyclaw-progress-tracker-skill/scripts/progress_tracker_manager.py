#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Manage KrabbyClaw progress tracker state with full ASM-linked components."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

STATUS_VALUES = ("queued", "running", "completed", "failed", "cancelled")

STORY_STEPS: tuple[dict[str, Any], ...] = (
    {
        "id": "starter",
        "title": "Starter + Pokedex",
        "asmLabel": "ElmsLab_AfterCyndaquilTotodileChikorita",
        "description": "Pick starter, receive Pokedex and Poke Balls to unlock wild captures.",
        "prerequisites": [],
        "setFlag": "EVENT_GOT_A_POKEMON_FROM_ELM",
        "applyMovement": "ElmsLabElmWalksToPlayerMovement",
        "mapRoute": "New Bark Town -> Elm's Lab",
    },
    {
        "id": "mr-pokemon",
        "title": "Mr. Pokemon + Mystery Egg",
        "asmLabel": "MrPokemonEventScript",
        "description": "Deliver Elm's errand and trigger Pokedex progression return path.",
        "prerequisites": ["starter"],
        "setFlag": "EVENT_GOT_MYSTERY_EGG_FROM_MR_POKEMON",
        "applyMovement": "MrPokemonHouseOakGivesPokedexMovement",
        "mapRoute": "Route 30 -> Mr. Pokemon's House",
    },
    {
        "id": "violet-badge",
        "title": "Zephyr Badge",
        "asmLabel": "VioletGymFalknerScript",
        "description": "Defeat Falkner and establish first badge gate progression.",
        "prerequisites": ["mr-pokemon"],
        "setFlag": "ENGINE_ZEPHYRBADGE",
        "applyMovement": "VioletGymGuyWalksToPlayer",
        "mapRoute": "Violet City -> Violet Gym",
    },
    {
        "id": "union-cave",
        "title": "Union Cave Transit",
        "asmLabel": "UnionCaveB1F_MapScripts",
        "description": "Cross Union Cave to access Azalea branch and Johto midgame scripts.",
        "prerequisites": ["violet-badge"],
        "setFlag": "EVENT_RIVAL_AZALEA_TOWN",
        "applyMovement": "AzaleaTownRivalBattleApproachMovement",
        "mapRoute": "Route 32 -> Union Cave -> Azalea",
    },
    {
        "id": "slowpoke-well",
        "title": "Slowpoke Well Clear",
        "asmLabel": "SlowpokeWellB1FRocketScript",
        "description": "Defeat Rocket in well and unlock Kurt + Azalea Gym completion.",
        "prerequisites": ["union-cave"],
        "setFlag": "EVENT_CLEARED_SLOWPOKE_WELL",
        "applyMovement": "SlowpokeWellKurtWalksToPlayerMovement",
        "mapRoute": "Azalea Town -> Slowpoke Well",
    },
    {
        "id": "hive-badge",
        "title": "Hive Badge",
        "asmLabel": "AzaleaGymBugsyScript",
        "description": "Defeat Bugsy and unlock Cut progression through Ilex Forest.",
        "prerequisites": ["slowpoke-well"],
        "setFlag": "ENGINE_HIVEBADGE",
        "applyMovement": "AzaleaGymBugsyBadgeGiveMovement",
        "mapRoute": "Azalea Town -> Azalea Gym",
    },
    {
        "id": "ilex-cut",
        "title": "Ilex Forest + Cut Gate",
        "asmLabel": "IlexForestFarfetchdScript",
        "description": "Complete charcoal/Farfetch'd sequence and pass through forest to Goldenrod.",
        "prerequisites": ["hive-badge"],
        "setFlag": "EVENT_CHARCOAL_KILN_BOSS",
        "applyMovement": "IlexForestFarfetchdChaseMovement",
        "mapRoute": "Azalea -> Ilex Forest -> Route 34",
    },
    {
        "id": "plain-badge",
        "title": "Plain Badge",
        "asmLabel": "GoldenrodGymWhitneyScript",
        "description": "Defeat Whitney to continue normal city progression and radio access pathing.",
        "prerequisites": ["ilex-cut"],
        "setFlag": "ENGINE_PLAINBADGE",
        "applyMovement": "GoldenrodGymWhitneyCryingMovement",
        "mapRoute": "Goldenrod City -> Goldenrod Gym",
    },
    {
        "id": "fog-badge",
        "title": "Fog Badge",
        "asmLabel": "EcruteakGymMortyScript",
        "description": "Defeat Morty to unlock Surf-dependent route branches.",
        "prerequisites": ["plain-badge"],
        "setFlag": "ENGINE_FOGBADGE",
        "applyMovement": "EcruteakGymMortyWalkToPlayerMovement",
        "mapRoute": "Ecruteak City -> Ecruteak Gym",
    },
    {
        "id": "cianwood-medicine",
        "title": "Cianwood Medicine",
        "asmLabel": "CianwoodPharmacyJasmineAmphyScript",
        "description": "Deliver SecretPotion to Ampharos and reopen Olivine gym progression.",
        "prerequisites": ["fog-badge"],
        "setFlag": "EVENT_GOT_SECRETPOTION_FROM_PHARMACY",
        "applyMovement": "OlivineLighthouseJasmineRequestsMedicineMovement",
        "mapRoute": "Ecruteak -> Olivine -> Cianwood -> Olivine Lighthouse",
    },
    {
        "id": "storm-badge",
        "title": "Storm Badge",
        "asmLabel": "CianwoodGymChuckScript",
        "description": "Defeat Chuck and earn Fly utility for efficient Johto progression.",
        "prerequisites": ["fog-badge"],
        "setFlag": "ENGINE_STORMBADGE",
        "applyMovement": "CianwoodGymChuckLiftBoulderMovement",
        "mapRoute": "Cianwood City -> Cianwood Gym",
    },
    {
        "id": "mineral-badge",
        "title": "Mineral Badge",
        "asmLabel": "OlivineGymJasmineScript",
        "description": "Defeat Jasmine after medicine event and close western Johto badge gate.",
        "prerequisites": ["cianwood-medicine"],
        "setFlag": "ENGINE_MINERALBADGE",
        "applyMovement": "OlivineGymJasmineApproachMovement",
        "mapRoute": "Olivine City -> Olivine Gym",
    },
    {
        "id": "mahogany-rocket",
        "title": "Mahogany Hideout",
        "asmLabel": "TeamRocketBaseB3FTrapDoorScript",
        "description": "Shut down Lake of Rage signal in Team Rocket hideout.",
        "prerequisites": ["mineral-badge", "storm-badge"],
        "setFlag": "EVENT_CLEARED_ROCKET_HIDEOUT",
        "applyMovement": "TeamRocketBaseLanceHyperBeamMovement",
        "mapRoute": "Mahogany -> Rocket Hideout",
    },
    {
        "id": "glacier-badge",
        "title": "Glacier Badge",
        "asmLabel": "MahoganyGymPryceScript",
        "description": "Defeat Pryce to satisfy Radio Tower takeover trigger conditions.",
        "prerequisites": ["mahogany-rocket"],
        "setFlag": "ENGINE_GLACIERBADGE",
        "applyMovement": "MahoganyGymPryceBadgeGiveMovement",
        "mapRoute": "Mahogany Town -> Mahogany Gym",
    },
    {
        "id": "goldenrod-rocket",
        "title": "Goldenrod Rocket Takeover",
        "asmLabel": "RadioTowerRocketsScript",
        "description": "Clear Radio Tower and obtain Basement Key/Card Key progression.",
        "prerequisites": ["glacier-badge"],
        "setFlag": "EVENT_CLEARED_RADIO_TOWER",
        "applyMovement": "RadioTowerDirectorGivesClearBellMovement",
        "mapRoute": "Goldenrod Underground -> Radio Tower",
    },
    {
        "id": "rising-badge",
        "title": "Rising Badge",
        "asmLabel": "BlackthornGymClairScript",
        "description": "Defeat Clair and complete Dragon's Den test for final Johto badge.",
        "prerequisites": ["goldenrod-rocket"],
        "setFlag": "ENGINE_RISINGBADGE",
        "applyMovement": "DragonsDenElderDratiniQuizMovement",
        "mapRoute": "Blackthorn Gym -> Dragon's Den",
    },
    {
        "id": "kimono-clear-bell",
        "title": "Kimono Girls + Clear Bell",
        "asmLabel": "EcruteakTinTowerEntranceScript",
        "description": "Resolve Kimono Girls sequence and unlock Tin Tower/legendary path.",
        "prerequisites": ["goldenrod-rocket"],
        "setFlag": "EVENT_GOT_CLEAR_BELL",
        "applyMovement": "KimonoGirlsDanceTheaterExitMovement",
        "mapRoute": "Ecruteak Theater -> Tin Tower",
    },
    {
        "id": "johto-champion",
        "title": "Elite Four Champion",
        "asmLabel": "LancesRoomLanceScript",
        "description": "Defeat Elite Four + Lance to unlock S.S. Aqua and Kanto.",
        "prerequisites": ["rising-badge"],
        "setFlag": "EVENT_BEAT_CHAMPION_LANCE",
        "applyMovement": "HallOfFameOakMaryEscortMovement",
        "mapRoute": "Victory Road -> Indigo Plateau",
    },
    {
        "id": "power-plant",
        "title": "Power Plant Restored",
        "asmLabel": "PowerPlantManagerScript",
        "description": "Return Machine Part and reactivate Kanto rail/radio progression gates.",
        "prerequisites": ["johto-champion"],
        "setFlag": "EVENT_RETURNED_MACHINE_PART",
        "applyMovement": "PowerPlantManagerRewardsPlayerMovement",
        "mapRoute": "Cerulean Gym -> Power Plant",
    },
    {
        "id": "blue-unlocked",
        "title": "Viridian Gym Unlocked",
        "asmLabel": "BlueHouseDaisyScript",
        "description": "Resolve Blue's availability by completing Cinnabar/Mt. Moon conditions.",
        "prerequisites": ["power-plant"],
        "setFlag": "EVENT_BLUE_IN_CINNABAR",
        "applyMovement": "ViridianGymBlueReturnsMovement",
        "mapRoute": "Cinnabar -> Seafoam -> Viridian",
    },
    {
        "id": "kanto-badges",
        "title": "All 16 Badges",
        "asmLabel": "ViridianGymBlueScript",
        "description": "Collect all Johto + Kanto badges and trigger Mt. Silver access from Oak.",
        "prerequisites": ["blue-unlocked"],
        "setFlag": "ENGINE_EARTHBADGE",
        "applyMovement": "PalletTownOakUnlocksMtSilverMovement",
        "mapRoute": "All Kanto gyms + Viridian Gym",
    },
    {
        "id": "red-defeated",
        "title": "Defeat Red",
        "asmLabel": "RedScript",
        "description": "Final battle clear condition for Crystal end-to-end completion.",
        "prerequisites": ["kanto-badges"],
        "setFlag": "EVENT_BEAT_RED",
        "applyMovement": "MtSilverSummitRedDespawnMovement",
        "mapRoute": "Mt. Silver Summit",
    },
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--state-file",
        default="~/.krabbyclaw-progress-tracker.json",
        help="Path for local tracker state.",
    )
    parser.add_argument(
        "--complete",
        action="append",
        default=[],
        help="Mark step id complete. Repeat for multiple steps.",
    )
    parser.add_argument(
        "--uncomplete",
        action="append",
        default=[],
        help="Mark step id incomplete. Repeat for multiple steps.",
    )
    parser.add_argument("--set-status", choices=STATUS_VALUES)
    parser.add_argument("--frame-count", type=int)
    parser.add_argument("--badge-count", type=int)
    parser.add_argument("--pokedex-seen", type=int)
    parser.add_argument("--pokedex-caught", type=int)
    parser.add_argument("--step-count", type=int)
    parser.add_argument("--instruction-count", type=int)
    parser.add_argument(
        "--list-components",
        action="store_true",
        help="Include all component fields for every story step.",
    )
    parser.add_argument(
        "--export-mermaid",
        action="store_true",
        help="Include the Mermaid diagram text in output.",
    )
    parser.add_argument(
        "--emit-progress-payload",
        action="store_true",
        help="Emit JSON payload compatible with POST /api/arena/progress.",
    )
    parser.add_argument(
        "--session-id", default="", help="Session id for progress payload output."
    )
    parser.add_argument(
        "--agent-name", default="", help="Agent name for progress payload output."
    )
    parser.add_argument(
        "--queue", default="main", help="Queue name for progress payload output."
    )
    parser.add_argument(
        "--runtime",
        default="mcp-http",
        help="Runtime name for progress payload output.",
    )
    parser.add_argument("--repo-url", default="")
    parser.add_argument("--model-url", default="")
    parser.add_argument("--note", default="")
    parser.add_argument("--error", default="")
    parser.add_argument("--json", action="store_true", help="Output JSON (default).")
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Compact JSON output.",
    )
    return parser.parse_args()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def resolve_state_file(raw_path: str) -> Path:
    return Path(raw_path).expanduser().resolve()


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"State file is not valid JSON: {path}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit(f"State file root must be a JSON object: {path}")
    return parsed


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2, ensure_ascii=True) + "\n"
    path.write_text(text, encoding="utf-8")


def unique_in_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            ordered.append(item)
    return ordered


def topological_sort(steps: tuple[dict[str, Any], ...]) -> list[str]:
    step_map = {step["id"]: step for step in steps}
    in_degree = {step["id"]: 0 for step in steps}

    for step in steps:
        for prerequisite in step["prerequisites"]:
            in_degree[step["id"]] = in_degree.get(step["id"], 0) + 1
            if prerequisite not in step_map:
                continue

    queue = [step_id for step_id, degree in in_degree.items() if degree == 0]

    order: list[str] = []
    while queue:
        step_id = queue.pop(0)
        order.append(step_id)

        for step in steps:
            if step_id not in step["prerequisites"]:
                continue
            next_degree = in_degree.get(step["id"], 0) - 1
            in_degree[step["id"]] = next_degree
            if next_degree == 0:
                queue.append(step["id"])

    return order


def validate_story_graph(steps: tuple[dict[str, Any], ...]) -> dict[str, Any]:
    step_ids = {step["id"] for step in steps}
    dangling = [
        f"{step['id']}:{prerequisite}"
        for step in steps
        for prerequisite in step["prerequisites"]
        if prerequisite not in step_ids
    ]

    ordered_step_ids = topological_sort(steps)
    is_acyclic = len(ordered_step_ids) == len(steps)

    seen: set[str] = set()

    def walk(step_id: str) -> bool:
        if step_id == "red-defeated":
            return True
        if step_id in seen:
            return False
        seen.add(step_id)
        dependents = [step for step in steps if step_id in step["prerequisites"]]
        return any(walk(step["id"]) for step in dependents)

    return {
        "isAcyclic": is_acyclic,
        "hasDanglingReferences": len(dangling) > 0,
        "isRedReachable": walk("starter"),
        "orderedStepIds": ordered_step_ids,
        "danglingPrerequisites": dangling,
    }


def load_state(path: Path) -> dict[str, Any]:
    payload = _read_json(path)
    completed_raw = payload.get("completedStepIds")
    completed_step_ids = (
        [str(step).strip() for step in completed_raw if str(step).strip()]
        if isinstance(completed_raw, list)
        else []
    )

    telemetry_raw = payload.get("telemetry")
    telemetry: dict[str, int] = {
        "frameCount": 0,
        "badgeCount": 0,
        "pokedexSeen": 0,
        "pokedexCaught": 0,
        "stepCount": 0,
        "instructionCount": 0,
    }
    if isinstance(telemetry_raw, dict):
        for key in telemetry:
            value = telemetry_raw.get(key)
            if isinstance(value, int):
                telemetry[key] = max(0, value)

    status_raw = payload.get("status")
    status = status_raw if status_raw in STATUS_VALUES else "running"

    return {
        "version": 1,
        "completedStepIds": unique_in_order(completed_step_ids),
        "telemetry": telemetry,
        "status": status,
        "updatedAt": payload.get("updatedAt")
        if isinstance(payload.get("updatedAt"), str)
        else None,
    }


def get_available_step_ids(
    steps: tuple[dict[str, Any], ...], completed_step_ids: list[str]
) -> list[str]:
    completed = set(completed_step_ids)
    return [
        step["id"]
        for step in steps
        if step["id"] not in completed
        and all(prerequisite in completed for prerequisite in step["prerequisites"])
    ]


def calculate_completion_percent(
    steps: tuple[dict[str, Any], ...], completed_step_ids: list[str]
) -> int:
    if not steps:
        return 0
    completed = set(completed_step_ids)
    done = sum(1 for step in steps if step["id"] in completed)
    return round((done / len(steps)) * 100)


def build_mermaid_diagram(
    steps: tuple[dict[str, Any], ...], completed_step_ids: list[str]
) -> str:
    completed = set(completed_step_ids)
    available = set(get_available_step_ids(steps, completed_step_ids))
    lines = ["flowchart TD", "  start([New Bark Town])"]

    for step in steps:
        lines.append(
            f'  {step["id"]}["{step["title"]}\\n{step["mapRoute"]}\\n{step["asmLabel"]}"]'
        )
        if not step["prerequisites"]:
            lines.append(f"  start --> {step['id']}")
        for requirement in step["prerequisites"]:
            lines.append(f"  {requirement} --> {step['id']}")

        if step["id"] in completed:
            lines.append(f"  class {step['id']} done;")
        elif step["id"] in available:
            lines.append(f"  class {step['id']} ready;")
        else:
            lines.append(f"  class {step['id']} todo;")

    lines.append(
        "  classDef done fill:#14532d,color:#ecfccb,stroke:#86efac,stroke-width:2px;"
    )
    lines.append(
        "  classDef ready fill:#92400e,color:#fffbeb,stroke:#f59e0b,stroke-width:2px;"
    )
    lines.append(
        "  classDef todo fill:#27272a,color:#e4e4e7,stroke:#a1a1aa,stroke-width:1px;"
    )
    return "\n".join(lines)


def parse_step_args(raw_args: list[str]) -> list[str]:
    parsed: list[str] = []
    for raw in raw_args:
        parts = [segment.strip() for segment in str(raw).split(",")]
        parsed.extend([part for part in parts if part])
    return parsed


def apply_updates(
    state: dict[str, Any], args: argparse.Namespace, steps: tuple[dict[str, Any], ...]
) -> dict[str, Any]:
    step_ids = {step["id"] for step in steps}
    completed = [
        step_id for step_id in state["completedStepIds"] if step_id in step_ids
    ]

    for step_id in parse_step_args(args.complete):
        if step_id not in step_ids:
            raise SystemExit(f"Unknown --complete step id: {step_id}")
        if step_id not in completed:
            completed.append(step_id)

    for step_id in parse_step_args(args.uncomplete):
        if step_id not in step_ids:
            raise SystemExit(f"Unknown --uncomplete step id: {step_id}")
        completed = [current for current in completed if current != step_id]

    telemetry = dict(state["telemetry"])
    for key, value in {
        "frameCount": args.frame_count,
        "badgeCount": args.badge_count,
        "pokedexSeen": args.pokedex_seen,
        "pokedexCaught": args.pokedex_caught,
        "stepCount": args.step_count,
        "instructionCount": args.instruction_count,
    }.items():
        if value is not None:
            telemetry[key] = max(0, int(value))

    if telemetry["stepCount"] == 0 and completed:
        telemetry["stepCount"] = len(completed)

    status = args.set_status if args.set_status else state["status"]

    return {
        "version": 1,
        "completedStepIds": unique_in_order(completed),
        "telemetry": telemetry,
        "status": status,
        "updatedAt": utc_now_iso(),
    }


def build_summary(
    state: dict[str, Any],
    steps: tuple[dict[str, Any], ...],
    *,
    include_components: bool,
) -> dict[str, Any]:
    completed_step_ids = [step_id for step_id in state["completedStepIds"]]
    available_step_ids = get_available_step_ids(steps, completed_step_ids)
    step_map = {step["id"]: step for step in steps}

    next_steps = [
        {
            "id": step_id,
            "title": step_map[step_id]["title"],
            "description": step_map[step_id]["description"],
            "asmLabel": step_map[step_id]["asmLabel"],
            "setFlag": step_map[step_id]["setFlag"],
            "applyMovement": step_map[step_id]["applyMovement"],
            "mapRoute": step_map[step_id]["mapRoute"],
        }
        for step_id in available_step_ids
    ]

    summary: dict[str, Any] = {
        "completionPercent": calculate_completion_percent(steps, completed_step_ids),
        "completedCount": len(completed_step_ids),
        "totalSteps": len(steps),
        "remainingCount": len(steps) - len(completed_step_ids),
        "completedStepIds": completed_step_ids,
        "availableStepIds": available_step_ids,
        "nextSteps": next_steps,
        "status": state["status"],
        "telemetry": state["telemetry"],
        "updatedAt": state["updatedAt"],
    }

    if include_components:
        summary["storyComponents"] = [
            {
                "id": step["id"],
                "title": step["title"],
                "description": step["description"],
                "prerequisites": step["prerequisites"],
                "asmLabel": step["asmLabel"],
                "setFlag": step["setFlag"],
                "applyMovement": step["applyMovement"],
                "mapRoute": step["mapRoute"],
            }
            for step in steps
        ]

    return summary


def build_progress_payload(
    args: argparse.Namespace, state: dict[str, Any], summary: dict[str, Any]
) -> dict[str, Any]:
    if not args.session_id.strip():
        raise SystemExit("--session-id is required with --emit-progress-payload")
    if not args.agent_name.strip():
        raise SystemExit("--agent-name is required with --emit-progress-payload")

    telemetry = state["telemetry"]
    return {
        "sessionId": args.session_id.strip(),
        "agentName": args.agent_name.strip(),
        "status": state["status"],
        "queue": args.queue.strip() or "main",
        "runtime": args.runtime.strip() or "mcp-http",
        "frameCount": telemetry["frameCount"],
        "badgeCount": telemetry["badgeCount"],
        "pokedexSeen": telemetry["pokedexSeen"],
        "pokedexCaught": telemetry["pokedexCaught"],
        "stepCount": telemetry["stepCount"] or summary["completedCount"],
        "instructionCount": telemetry["instructionCount"],
        "repoUrl": args.repo_url.strip() or None,
        "modelUrl": args.model_url.strip() or None,
        "note": args.note.strip() or None,
        "error": args.error.strip() or None,
    }


def _print_json(payload: dict[str, Any], compact: bool) -> None:
    if compact:
        print(json.dumps(payload, separators=(",", ":"), ensure_ascii=True))
        return
    print(json.dumps(payload, indent=2, ensure_ascii=True))


def main() -> int:
    args = parse_args()

    validation = validate_story_graph(STORY_STEPS)
    if (
        not validation["isAcyclic"]
        or validation["hasDanglingReferences"]
        or not validation["isRedReachable"]
    ):
        raise SystemExit(
            "Invalid story graph: "
            f"acyclic={validation['isAcyclic']} "
            f"dangling={validation['hasDanglingReferences']} "
            f"redReachable={validation['isRedReachable']}"
        )

    state_path = resolve_state_file(args.state_file)
    existing_state = load_state(state_path)
    updated_state = apply_updates(existing_state, args, STORY_STEPS)
    _write_json(state_path, updated_state)

    summary = build_summary(
        updated_state, STORY_STEPS, include_components=args.list_components
    )
    output: dict[str, Any] = {
        "graphValidation": validation,
        "summary": summary,
    }

    if args.export_mermaid:
        output["mermaid"] = build_mermaid_diagram(
            STORY_STEPS, updated_state["completedStepIds"]
        )

    if args.emit_progress_payload:
        output["progressPayload"] = build_progress_payload(args, updated_state, summary)

    _print_json(output, compact=args.compact)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
